import * as PostApiUtil from '../util/post_api_util';
import { hashHistory } from 'react-router';