import React from 'react';

class PostForm extends React.Component {

  render () {
    return (
      <div>
      </div>
    );
  }
}

export default PostForm;
