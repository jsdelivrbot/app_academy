import React from 'react';
import { Link, hashHistory } from 'react-router';

const PostIndexItem = props => (
  <li>
  </li>
);

export default PostIndexItem;
