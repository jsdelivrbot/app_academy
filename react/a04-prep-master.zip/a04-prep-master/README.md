# a04-prep

## How to prepare

Know Auth!!!

The following is a (non-exhaustive) list of topics that may be covered:

+ Authentication
+ Basic CRUD (Create, Read, Update, Delete) operations in ruby on rails.
+ Lather, rinse, repeat the practice assessment and learn how to read the [Capybara][capybara] specs.

**Resources**:
* :video_camera: [Assessment Seminar Video](https://vimeo.com/169371159) (go_video_go)

[capybara]: https://github.com/jnicklas/capybara
